const Players = () => {
  return (
    <div className="min-h-screen py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="font-krub font-bold text-4xl text-white mb-8">Players</h1>
        <div className="prose prose-lg text-gray-300">
          <p className="font-lexend text-xl leading-relaxed">
            Coming soon... Detailed profiles of all our players, statistics, and career highlights.
          </p>
        </div>
      </div>
    </div>
  )
}

export default Players
