import HeroSection from "../components/HeroSection"
import PlayersSection from "../components/PlayersSection"
import NewsSection from "../components/NewsSection"
import FixturesSection from "../components/FixturesSection"
import SponsorsSection from "../components/SponsorsSection"
import MerchandiseSection from "../components/MerchandiseSection"

const Home = () => {
  return (
    <main>
      <HeroSection />
      <PlayersSection />
      <FixturesSection />
      <NewsSection />
      <MerchandiseSection />
      <SponsorsSection />
    </main>
  )
}

export default Home
