const HeroSection = () => {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(rgba(25, 54, 97, 0.8), rgba(25, 54, 97, 0.6)), url('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-9q2J3YYphNjRV4YQ7ijl07mpopnmli.png')`,
        }}
      />

      {/* Content */}
      <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
        <h1 className="font-krub font-bold text-5xl md:text-7xl text-white mb-6 text-balance">Win the Championship</h1>
        <p className="font-lexend text-xl md:text-2xl text-gray-200 mb-8 text-pretty">
          Join the legacy of champions. Experience the passion, skill, and dedication that defines Dekedda Sports Club.
        </p>
        <button className="bg-red-600 hover:bg-red-700 text-white font-lexend font-semibold px-8 py-4 rounded-lg transition-colors duration-200 text-lg">
          Join Now
        </button>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  )
}

export default HeroSection
