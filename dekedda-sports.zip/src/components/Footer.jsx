const Footer = () => {
  return (
    <footer className="bg-primary-dark border-t border-primary-light/20 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Club Info */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-f4CKAJJMVM4gfeynBvgA3PRbZShC7L.png"
                alt="Dekedda Sports Club"
                className="h-12 w-auto"
              />
              <div>
                <h3 className="font-krub font-bold text-xl text-white">DEKEDDA</h3>
                <p className="text-primary-light font-lexend">SPORTS CLUB</p>
              </div>
            </div>
            <p className="text-gray-300 font-lexend mb-4">
              Established in 1999, Dekedda Sports Club has been a cornerstone of excellence in football, developing
              world-class players and creating unforgettable moments for our passionate fans.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-krub font-semibold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="/team" className="text-gray-300 hover:text-primary-light font-lexend">
                  Team
                </a>
              </li>
              <li>
                <a href="/players" className="text-gray-300 hover:text-primary-light font-lexend">
                  Players
                </a>
              </li>
              <li>
                <a href="/news" className="text-gray-300 hover:text-primary-light font-lexend">
                  News
                </a>
              </li>
              <li>
                <a href="/seasons" className="text-gray-300 hover:text-primary-light font-lexend">
                  Seasons
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-krub font-semibold text-white mb-4">Contact</h4>
            <ul className="space-y-2 text-gray-300 font-lexend">
              <li>Stadium Address</li>
              <li>City, Country</li>
              <li>+1 (555) 123-4567</li>
              <li>info@dekedda.com</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-light/20 mt-8 pt-8 text-center">
          <p className="text-gray-400 font-lexend">© 2024 Dekedda Sports Club. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
