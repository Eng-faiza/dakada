import Home from "../src/pages/Home"

export default function Page() {
  return <Home />
}
